"""
mail_setup.py
=============
Email notification setup for complaint updates.
Sends email to user when complaint status changes.
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

# ── Config (set in .env) ──────────────────────────────────────
MAIL_SERVER   = os.environ.get('MAIL_SERVER',   'smtp.gmail.com')
MAIL_PORT     = int(os.environ.get('MAIL_PORT', 587))
MAIL_USERNAME = os.environ.get('MAIL_USERNAME', '')
MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD', '')
MAIL_FROM     = os.environ.get('MAIL_FROM',     'noreply@swachhbharat.in')


def send_complaint_confirmation(to_email: str, name: str, complaint_id: int, city: str):
    """Send confirmation email when complaint is registered."""
    if not MAIL_USERNAME:
        return False  # Email not configured

    subject = f"Complaint #{complaint_id} Registered – Swachh Bharat"
    body = f"""
Dear {name},

Your complaint has been successfully registered.

Complaint ID : #{complaint_id}
City         : {city.title()}
Status       : Pending

Our team will look into this and take action shortly.

Thank you for helping keep India clean!

– Swachh Bharat Mission Team
"""
    return _send_email(to_email, subject, body)


def send_status_update(to_email: str, name: str, complaint_id: int, new_status: str):
    """Send email when complaint status is updated."""
    if not MAIL_USERNAME:
        return False

    subject = f"Complaint #{complaint_id} Status Update – {new_status}"
    body = f"""
Dear {name},

Your complaint #{complaint_id} status has been updated.

New Status : {new_status}

{"Your issue has been resolved. Thank you for your patience!" if new_status == "Resolved" else "Our team is working on your complaint."}

– Swachh Bharat Mission Team
"""
    return _send_email(to_email, subject, body)


def _send_email(to_email: str, subject: str, body: str) -> bool:
    """Internal helper to send email via SMTP."""
    try:
        msg = MIMEMultipart()
        msg['From']    = MAIL_FROM
        msg['To']      = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        with smtplib.SMTP(MAIL_SERVER, MAIL_PORT) as server:
            server.starttls()
            server.login(MAIL_USERNAME, MAIL_PASSWORD)
            server.send_message(msg)
        return True
    except Exception as e:
        print(f"[Email Error] {e}")
        return False
