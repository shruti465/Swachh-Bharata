from flask import Flask, render_template, session, redirect, url_for
import pymysql
import pymysql.cursors
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'swachh-bharat-secret-2024')

DB_CONFIG = {
    'host':        os.environ.get('MYSQL_HOST', 'localhost'),
    'user':        os.environ.get('MYSQL_USER', 'root'),
    'password':    os.environ.get('MYSQL_PASSWORD', ''),
    'database':    os.environ.get('MYSQL_DB', 'swachh_bharat'),
    'cursorclass': pymysql.cursors.DictCursor,
    'charset':     'utf8mb4',
}

def get_db():
    return pymysql.connect(**DB_CONFIG)

app.get_db = get_db

from routes.user_routes    import user_bp
from routes.staff_routes   import staff_bp
from routes.worker_routes  import worker_bp
from routes.central_routes import central_bp
from routes.geo_routes     import geo_bp

app.register_blueprint(user_bp,    url_prefix='/user')
app.register_blueprint(staff_bp,   url_prefix='/staff')
app.register_blueprint(worker_bp,  url_prefix='/worker')
app.register_blueprint(central_bp, url_prefix='/central')
app.register_blueprint(geo_bp,     url_prefix='/geo')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
